# Installation Guide

## Table of Contents
1. [System Requirements](#system-requirements)
2. [Backend Installation](#backend-installation)
3. [Frontend Installation](#frontend-installation)
4. [Configuration](#configuration)
5. [Verification](#verification)
6. [Troubleshooting](#troubleshooting)

## System Requirements

### Hardware Requirements
- CPU: 4+ cores, 2.5GHz or higher
- RAM: 16GB minimum, 32GB recommended
- Storage: 50GB available space
- Network: 1Gbps Ethernet connection

### Software Requirements
- Operating System:
  - Windows 10/11 (64-bit)
  - Linux (Ubuntu 20.04 LTS or later)
  - macOS 10.15 or later
- Python 3.8 or higher
- Node.js 14.0 or higher
- npm 6.0 or higher
- Git

## Backend Installation

### 1. Clone the Repository
```bash
git clone https://github.com/your-organization/pythonspace.git
cd pythonspace
```

### 2. Set Up Virtual Environment
```bash
# Windows
python -m venv venv
.\venv\Scripts\activate

# Unix/MacOS
python -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies
```bash
cd backend
pip install -r requirements.txt
```

### 4. Configure Environment Variables
Create a `.env` file in the backend directory:
```bash
# Backend Configuration
QUANTUM_SYSTEM_HOST=localhost
QUANTUM_SYSTEM_PORT=8000
QUANTUM_SYSTEM_DEBUG=True
QUANTUM_SYSTEM_SECRET_KEY=your-secret-key
```

### 5. Initialize Database
```bash
# Create necessary directories
mkdir -p backend/static
mkdir -p backend/logs
```

## Frontend Installation

### 1. Install Dependencies
```bash
cd frontend
npm install
```

### 2. Configure Environment Variables
Create a `.env` file in the frontend directory:
```bash
# Frontend Configuration
REACT_APP_API_URL=http://localhost:8000
REACT_APP_WS_URL=ws://localhost:8000
REACT_APP_ENV=development
```

### 3. Build the Application
```bash
npm run build
```

## Configuration

### Backend Configuration
1. **Database Setup**
   ```python
   # backend/main.py
   DATABASE_CONFIG = {
       "host": "localhost",
       "port": 5432,
       "database": "quantum_db",
       "user": "quantum_user",
       "password": "your-secure-password"
   }
   
   # For SQLite (development)
   DATABASE_URL = "sqlite:///./quantum.db"
   
   # For PostgreSQL (production)
   DATABASE_URL = f"postgresql://{DATABASE_CONFIG['user']}:{DATABASE_CONFIG['password']}@{DATABASE_CONFIG['host']}:{DATABASE_CONFIG['port']}/{DATABASE_CONFIG['database']}"
   ```

2. **Security Settings**
   ```python
   # backend/.env
   QUANTUM_SYSTEM_SECRET_KEY=your-256-bit-secret-key
   JWT_SECRET_KEY=your-jwt-secret-key
   JWT_ALGORITHM=HS256
   ACCESS_TOKEN_EXPIRE_MINUTES=30
   
   # SSL Configuration
   SSL_CERT_PATH=/path/to/cert.pem
   SSL_KEY_PATH=/path/to/key.pem
   ```

3. **Performance Tuning**
   ```bash
   # backend/start.sh
   # Adjust worker settings
   export WORKER_COUNT=4
   export WORKER_TIMEOUT=120
   export MAX_REQUESTS=1000
   
   # Configure caching
   export CACHE_TYPE=redis
   export CACHE_REDIS_URL=redis://localhost:6379/0
   
   # Load balancing settings
   export LOAD_BALANCER_ENABLED=true
   export LOAD_BALANCER_ALGORITHM=round-robin
   ```

### Frontend Configuration
1. **API Integration**
   ```typescript
   // frontend/src/config/api.ts
   export const API_CONFIG = {
     baseURL: process.env.REACT_APP_API_URL,
     wsURL: process.env.REACT_APP_WS_URL,
     timeout: 30000,
     retryAttempts: 3,
     retryDelay: 1000
   };
   
   // WebSocket configuration
   export const WS_CONFIG = {
     reconnectInterval: 5000,
     maxReconnectAttempts: 5,
     heartbeatInterval: 30000
   };
   ```

2. **UI Customization**
   ```typescript
   // frontend/src/theme.ts
   export const theme = createTheme({
     palette: {
       mode: 'dark',
       primary: {
         main: '#90caf9',
         light: '#e3f2fd',
         dark: '#42a5f5'
       },
       secondary: {
         main: '#f48fb1',
         light: '#f8bbd0',
         dark: '#f06292'
       }
     },
     typography: {
       fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
       h1: { fontSize: '2.5rem', fontWeight: 500 },
       h2: { fontSize: '2rem', fontWeight: 500 }
     }
   });
   ```

## Platform-Specific Installation

### Windows Installation
1. **Prerequisites**
   ```powershell
   # Install Chocolatey package manager
   Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
   
   # Install required software
   choco install python git nodejs redis postgresql
   
   # Install development tools
   choco install visualstudio2019buildtools visualstudio2019-workload-vctools
   ```

2. **Environment Setup**
   ```powershell
   # Set environment variables
   $env:PYTHONPATH = "$env:PYTHONPATH;C:\path\to\pythonspace"
   $env:NODE_OPTIONS = "--max-old-space-size=4096"
   $env:PATH = "$env:PATH;C:\Program Files\PostgreSQL\13\bin"
   
   # Configure Python
   python -m pip install --upgrade pip
   python -m pip install virtualenv
   
   # Configure Node.js
   npm config set python python3.8
   npm config set msvs_version 2019
   ```

3. **Service Configuration**
   ```powershell
   # Create Windows service
   New-Service -Name "QuantumBackend" -BinaryPathName "C:\path\to\python.exe C:\path\to\start.py"
   
   # Configure service
   Set-Service -Name "QuantumBackend" -StartupType Automatic
   Set-Service -Name "QuantumBackend" -Description "Quantum Computing System Backend"
   ```

### Linux Installation
1. **Prerequisites**
   ```bash
   # Ubuntu/Debian
   sudo apt update
   sudo apt install -y python3.8 python3.8-venv python3-pip nodejs npm git redis-server postgresql postgresql-contrib
   
   # CentOS/RHEL
   sudo yum install -y python38 python38-devel nodejs npm git redis postgresql-server postgresql-contrib
   
   # Arch Linux
   sudo pacman -S python python-pip nodejs npm git redis postgresql
   ```

2. **System Configuration**
   ```bash
   # Increase system limits
   echo "* soft nofile 65535" | sudo tee -a /etc/security/limits.conf
   echo "* hard nofile 65535" | sudo tee -a /etc/security/limits.conf
   echo "fs.file-max = 65535" | sudo tee -a /etc/sysctl.conf
   
   # Configure PostgreSQL
   sudo -u postgres psql -c "CREATE USER quantum_user WITH PASSWORD 'your-password';"
   sudo -u postgres psql -c "CREATE DATABASE quantum_db OWNER quantum_user;"
   
   # Configure Redis
   sudo systemctl enable redis
   sudo systemctl start redis
   ```

3. **Service Management**
   ```bash
   # Create systemd service
   sudo nano /etc/systemd/system/quantum.service
   
   [Unit]
   Description=Quantum Computing System
   After=network.target postgresql.service redis.service
   
   [Service]
   User=quantum
   Group=quantum
   WorkingDirectory=/opt/quantum
   Environment="PATH=/opt/quantum/venv/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin"
   ExecStart=/opt/quantum/venv/bin/python start.py
   Restart=always
   
   [Install]
   WantedBy=multi-user.target
   ```

### macOS Installation
1. **Prerequisites**
   ```bash
   # Install Homebrew
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   
   # Install required software
   brew install python@3.8 node git redis postgresql@13
   
   # Install development tools
   brew install pkg-config
   ```

2. **Environment Setup**
   ```bash
   # Configure Python
   echo 'export PATH="/usr/local/opt/python@3.8/bin:$PATH"' >> ~/.zshrc
   echo 'export LDFLAGS="-L/usr/local/opt/python@3.8/lib"' >> ~/.zshrc
   echo 'export PKG_CONFIG_PATH="/usr/local/opt/python@3.8/lib/pkgconfig"' >> ~/.zshrc
   
   # Configure Node.js
   echo 'export NODE_OPTIONS="--max-old-space-size=4096"' >> ~/.zshrc
   
   # Configure PostgreSQL
   echo 'export PATH="/usr/local/opt/postgresql@13/bin:$PATH"' >> ~/.zshrc
   ```

3. **Service Management**
   ```bash
   # Start services
   brew services start redis
   brew services start postgresql@13
   
   # Configure PostgreSQL
   createdb quantum_db
   createuser quantum_user
   psql -d quantum_db -c "ALTER USER quantum_user WITH PASSWORD 'your-password';"
   ```

## Advanced Troubleshooting

### Database Issues
1. **Connection Problems**
   ```bash
   # Test PostgreSQL connection
   psql -h localhost -U quantum_user -d quantum_db -c "\conninfo"
   
   # Check PostgreSQL logs
   tail -f /var/log/postgresql/postgresql-13-main.log
   
   # Reset PostgreSQL password
   sudo -u postgres psql -c "ALTER USER quantum_user WITH PASSWORD 'new-password';"
   ```

2. **Performance Issues**
   ```sql
   -- Check active queries
   SELECT pid, age(clock_timestamp(), query_start), usename, query 
   FROM pg_stat_activity 
   WHERE query != '<IDLE>' AND query NOT ILIKE '%pg_stat_activity%' 
   ORDER BY query_start desc;
   
   -- Check table sizes
   SELECT relname, pg_size_pretty(pg_total_relation_size(relid)) 
   FROM pg_catalog.pg_statio_user_tables 
   ORDER BY pg_total_relation_size(relid) DESC;
   
   -- Check index usage
   SELECT schemaname, relname, idx_scan, idx_tup_read, idx_tup_fetch 
   FROM pg_stat_user_indexes;
   ```

### Network Issues
1. **Firewall Configuration**
   ```bash
   # Linux (UFW)
   sudo ufw allow 8000/tcp comment 'Quantum Backend'
   sudo ufw allow 3000/tcp comment 'Quantum Frontend'
   sudo ufw allow 5432/tcp comment 'PostgreSQL'
   sudo ufw allow 6379/tcp comment 'Redis'
   
   # Linux (iptables)
   sudo iptables -A INPUT -p tcp --dport 8000 -j ACCEPT
   sudo iptables -A INPUT -p tcp --dport 3000 -j ACCEPT
   sudo iptables-save | sudo tee /etc/iptables/rules.v4
   
   # Windows (Advanced Firewall)
   netsh advfirewall firewall add rule name="Quantum Backend" dir=in action=allow protocol=TCP localport=8000
   netsh advfirewall firewall add rule name="Quantum Frontend" dir=in action=allow protocol=TCP localport=3000
   netsh advfirewall firewall add rule name="PostgreSQL" dir=in action=allow protocol=TCP localport=5432
   netsh advfirewall firewall add rule name="Redis" dir=in action=allow protocol=TCP localport=6379
   ```

2. **SSL Certificate Issues**
   ```bash
   # Generate CA certificate
   openssl genrsa -out ca.key 4096
   openssl req -new -x509 -days 365 -key ca.key -out ca.crt
   
   # Generate server certificate
   openssl genrsa -out server.key 4096
   openssl req -new -key server.key -out server.csr
   openssl x509 -req -days 365 -in server.csr -CA ca.crt -CAkey ca.key -set_serial 01 -out server.crt
   
   # Verify certificate chain
   openssl verify -CAfile ca.crt server.crt
   ```

### Performance Issues
1. **Memory Management**
   ```bash
   # Monitor Python memory usage
   python -m memory_profiler your_script.py
   
   # Monitor Node.js memory usage
   node --inspect-brk your_script.js
   
   # Check system memory
   free -h
   vmstat 1
   
   # Check process memory
   ps aux | grep python
   ps aux | grep node
   ```

2. **CPU Optimization**
   ```bash
   # Set CPU affinity
   taskset -c 0,1,2,3 python start.py
   
   # Monitor CPU usage
   mpstat -P ALL 1
   top -b -n 1 | grep python
   top -b -n 1 | grep node
   
   # Check process priority
   nice -n -10 python start.py
   ```

### Security Issues
1. **Authentication Problems**
   ```bash
   # Reset user password
   python manage.py changepassword username
   
   # Check authentication logs
   tail -f /var/log/auth.log
   
   # Check failed login attempts
   grep "Failed password" /var/log/auth.log
   
   # Check user sessions
   who
   w
   ```

2. **SSL/TLS Configuration**
   ```bash
   # Test SSL configuration
   openssl s_client -connect localhost:8000 -servername localhost
   
   # Check certificate chain
   openssl s_client -showcerts -connect localhost:8000
   
   # Verify certificate dates
   openssl x509 -in server.crt -noout -dates
   
   # Check cipher suites
   openssl ciphers -v
   ```

## Enterprise Deployment

### High Availability Setup
1. **Load Balancer Configuration**
   ```nginx
   # nginx configuration
   upstream quantum_backend {
       server backend1:8000 weight=3;
       server backend2:8000 weight=2;
       server backend3:8000 weight=1;
       keepalive 32;
   }
   
   server {
       listen 80;
       server_name quantum.example.com;
       
       location / {
           proxy_pass http://quantum_backend;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
           
           # Timeouts
           proxy_connect_timeout 60s;
           proxy_send_timeout 60s;
           proxy_read_timeout 60s;
       }
       
       # Health check
       location /health {
           access_log off;
           return 200 'healthy\n';
       }
   }
   ```

2. **Database Replication**
   ```sql
   -- Primary database
   ALTER SYSTEM SET wal_level = replica;
   ALTER SYSTEM SET max_wal_senders = 10;
   ALTER SYSTEM SET max_replication_slots = 10;
   ALTER SYSTEM SET hot_standby = on;
   
   -- Replica database
   CREATE SUBSCRIPTION quantum_subscription
   CONNECTION 'host=primary dbname=quantum_db user=replicator password=your-password'
   PUBLICATION quantum_publication
   WITH (copy_data = true);
   
   -- Monitor replication
   SELECT * FROM pg_stat_replication;
   SELECT * FROM pg_stat_wal_receiver;
   ```

### Monitoring Setup
1. **Prometheus Configuration**
   ```yaml
   # prometheus.yml
   global:
     scrape_interval: 15s
     evaluation_interval: 15s
   
   scrape_configs:
     - job_name: 'quantum'
       static_configs:
         - targets: ['localhost:8000']
       metrics_path: '/metrics'
       scrape_interval: 5s
   
     - job_name: 'node'
       static_configs:
         - targets: ['localhost:9100']
   
     - job_name: 'postgres'
       static_configs:
         - targets: ['localhost:9187']
   ```

2. **Grafana Dashboard**
   ```json
   {
     "dashboard": {
       "title": "Quantum System Metrics",
       "panels": [
         {
           "title": "CPU Usage",
           "type": "graph",
           "datasource": "Prometheus",
           "targets": [
             {
               "expr": "rate(process_cpu_seconds_total[5m])",
               "legendFormat": "{{instance}}"
             }
           ]
         },
         {
           "title": "Memory Usage",
           "type": "graph",
           "datasource": "Prometheus",
           "targets": [
             {
               "expr": "process_resident_memory_bytes",
               "legendFormat": "{{instance}}"
             }
           ]
         },
         {
           "title": "Database Connections",
           "type": "graph",
           "datasource": "Prometheus",
           "targets": [
             {
               "expr": "pg_stat_activity_count",
               "legendFormat": "{{datname}}"
             }
           ]
         }
       ]
     }
   }
   ```

## Verification

### 1. Backend Verification
```bash
# Start the backend server
cd backend
python main.py

# Test API endpoints
curl http://localhost:8000/api/health
curl http://localhost:8000/api/quantum/state
curl http://localhost:8000/api/quantum/operations

# Check logs
tail -f backend/logs/quantum.log
```

### 2. Frontend Verification
```bash
# Start the frontend development server
cd frontend
npm start

# Open browser and verify
# Default URL: http://localhost:3000
```

### 3. Database Verification
```bash
# PostgreSQL
psql -U quantum_user -d quantum_db -c "\dt"
psql -U quantum_user -d quantum_db -c "SELECT * FROM quantum_states;"

# SQLite
sqlite3 backend/quantum.db ".tables"
sqlite3 backend/quantum.db "SELECT * FROM quantum_states;"
```

### 4. WebSocket Verification
```bash
# Test WebSocket connection
wscat -c ws://localhost:8000/ws
# Send test message
{"type": "ping"}
```

## Running the System

### 1. Development Mode
```bash
# Terminal 1 - Backend
cd backend
python main.py

# Terminal 2 - Frontend
cd frontend
npm start
```

### 2. Production Mode
```bash
# Backend
cd backend
./start.sh  # or start.bat on Windows

# Frontend
cd frontend
npm run build
serve -s build
```

### 3. Docker Deployment
```bash
# Build images
docker build -t quantum-backend ./backend
docker build -t quantum-frontend ./frontend

# Run containers
docker run -d -p 8000:8000 quantum-backend
docker run -d -p 3000:3000 quantum-frontend
```

## System Maintenance

### 1. Backups
```bash
# Database backup
pg_dump -U quantum_user quantum_db > backup.sql

# Configuration backup
tar -czf config_backup.tar.gz backend/.env frontend/.env
```

### 2. Updates
```bash
# Update backend
cd backend
git pull
pip install -r requirements.txt
python main.py

# Update frontend
cd frontend
git pull
npm install
npm run build
```

### 3. Monitoring
```bash
# Check system status
curl http://localhost:8000/api/status

# View logs
tail -f backend/logs/quantum.log
tail -f frontend/logs/app.log
```

## Common Issues and Solutions

### 1. Port Conflicts
```bash
# Check port usage
netstat -tuln | grep 8000
netstat -tuln | grep 3000

# Kill process using port
kill -9 $(lsof -t -i:8000)
```

### 2. Database Connection Issues
```bash
# Check PostgreSQL service
sudo systemctl status postgresql

# Reset PostgreSQL password
sudo -u postgres psql -c "ALTER USER quantum_user WITH PASSWORD 'new-password';"
```

### 3. Memory Issues
```bash
# Check memory usage
free -h
top

# Clear cache
sync; echo 3 > /proc/sys/vm/drop_caches
```

### 4. Network Issues
```bash
# Check firewall
sudo ufw status
sudo iptables -L

# Test connectivity
ping localhost
curl http://localhost:8000/api/health
```

## Support

For additional support:
1. Check the documentation in `quantum.md`
2. Review troubleshooting guides
3. Contact support@quantum-system.example.com
4. Visit the community forum at forum.quantum-system.example.com