# Contributing to Quantum Computing System

Thank you for your interest in contributing to our Quantum Computing System! This document provides guidelines and instructions for contributing to the project.

## Code of Conduct

By participating in this project, you agree to abide by our Code of Conduct. Please be respectful and considerate of others.

## Getting Started

1. Fork the repository
2. Clone your fork: `git clone https://github.com/your-username/pythonspace.git`
3. Create a new branch: `git checkout -b feature/your-feature-name`

## Development Setup

### Backend Setup
```bash
cd backend
python -m venv venv
source venv/bin/activate  # or .\venv\Scripts\activate on Windows
pip install -r requirements.txt
```

### Frontend Setup
```bash
cd frontend
npm install
```

## Making Changes

1. Make your changes following the project's coding standards
2. Write or update tests as needed
3. Update documentation if necessary
4. Run tests and ensure they pass
5. Commit your changes with a descriptive commit message
6. Push to your fork
7. Create a Pull Request

## Coding Standards

### Python (Backend)
- Follow PEP 8 style guide
- Use type hints
- Write docstrings for all public functions and classes
- Keep functions focused and small
- Use meaningful variable names

### TypeScript (Frontend)
- Follow the project's ESLint configuration
- Use TypeScript interfaces and types
- Write JSDoc comments for components and functions
- Follow React best practices
- Use functional components with hooks

## Testing

### Backend Tests
```bash
cd backend
pytest
```

### Frontend Tests
```bash
cd frontend
npm test
```

## Documentation

- Update relevant documentation when making changes
- Follow the existing documentation style
- Include examples where appropriate
- Keep documentation up-to-date

## Pull Request Process

1. Ensure your PR description clearly describes the problem and solution
2. Include relevant tests
3. Update documentation if needed
4. Ensure all tests pass
5. Request review from maintainers

## Review Process

- PRs will be reviewed by maintainers
- Feedback will be provided if changes are needed
- Once approved, your PR will be merged

## Questions?

If you have any questions, please:
1. Check the existing documentation
2. Search existing issues
3. Create a new issue if needed

Thank you for contributing! 