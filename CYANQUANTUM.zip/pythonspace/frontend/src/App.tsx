import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { styled } from '@mui/material/styles';

// Components
import Dashboard from './components/Dashboard';
import QuantumState from './components/QuantumState';
import Network from './components/Network';
import Monitoring from './components/Monitoring';
import Security from './components/Security';
import Optimization from './components/Optimization';
import Sidebar from './components/Sidebar';
import Header from './components/Header';

// Create theme
const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#90caf9',
    },
    secondary: {
      main: '#f48fb1',
    },
    background: {
      default: '#121212',
      paper: '#1e1e1e',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
  },
});

// Styled components
const AppContainer = styled('div')({
  display: 'flex',
  minHeight: '100vh',
});

const MainContent = styled('main')(({ theme }) => ({
  flexGrow: 1,
  padding: theme.spacing(3),
  marginLeft: 240, // Sidebar width
  backgroundColor: theme.palette.background.default,
}));

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <AppContainer>
          <Sidebar />
          <MainContent>
            <Header />
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/quantum-state" element={<QuantumState />} />
              <Route path="/network" element={<Network />} />
              <Route path="/monitoring" element={<Monitoring />} />
              <Route path="/security" element={<Security />} />
              <Route path="/optimization" element={<Optimization />} />
            </Routes>
          </MainContent>
        </AppContainer>
      </Router>
    </ThemeProvider>
  );
}

export default App; 