import React, { useEffect, useState } from 'react';
import { Box, Grid, Paper, Typography } from '@mui/material';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';
import { styled } from '@mui/material/styles';
import { useWebSocket } from '../hooks/useWebSocket';

// Register ChartJS components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

// Styled components
const DashboardContainer = styled(Box)(({ theme }) => ({
  padding: theme.spacing(3),
}));

const MetricCard = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
}));

interface SystemMetrics {
  cpu: number;
  memory: number;
  qubits: number;
  network: number;
}

const Dashboard: React.FC = () => {
  const [metrics, setMetrics] = useState<SystemMetrics>({
    cpu: 0,
    memory: 0,
    qubits: 0,
    network: 0,
  });

  const [performanceData, setPerformanceData] = useState<{
    labels: string[];
    datasets: {
      label: string;
      data: number[];
      borderColor: string;
    }[];
  }>({
    labels: [],
    datasets: [
      {
        label: 'CPU Usage',
        data: [],
        borderColor: '#90caf9',
      },
      {
        label: 'Memory Usage',
        data: [],
        borderColor: '#f48fb1',
      },
    ],
  });

  const { lastMessage } = useWebSocket();

  useEffect(() => {
    if (lastMessage) {
      const data = JSON.parse(lastMessage);
      setMetrics({
        cpu: data.cpu,
        memory: data.memory,
        qubits: data.qubits,
        network: data.network,
      });

      setPerformanceData(prev => ({
        labels: [...prev.labels, new Date().toLocaleTimeString()],
        datasets: [
          {
            ...prev.datasets[0],
            data: [...prev.datasets[0].data, data.cpu],
          },
          {
            ...prev.datasets[1],
            data: [...prev.datasets[1].data, data.memory],
          },
        ],
      }));
    }
  }, [lastMessage]);

  return (
    <DashboardContainer>
      <Typography variant="h4" gutterBottom>
        System Dashboard
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6} lg={3}>
          <MetricCard>
            <Typography variant="h6" gutterBottom>
              CPU Usage
            </Typography>
            <Typography variant="h4">
              {metrics.cpu}%
            </Typography>
          </MetricCard>
        </Grid>
        <Grid item xs={12} md={6} lg={3}>
          <MetricCard>
            <Typography variant="h6" gutterBottom>
              Memory Usage
            </Typography>
            <Typography variant="h4">
              {metrics.memory}%
            </Typography>
          </MetricCard>
        </Grid>
        <Grid item xs={12} md={6} lg={3}>
          <MetricCard>
            <Typography variant="h6" gutterBottom>
              Active Qubits
            </Typography>
            <Typography variant="h4">
              {metrics.qubits}
            </Typography>
          </MetricCard>
        </Grid>
        <Grid item xs={12} md={6} lg={3}>
          <MetricCard>
            <Typography variant="h6" gutterBottom>
              Network Load
            </Typography>
            <Typography variant="h4">
              {metrics.network}%
            </Typography>
          </MetricCard>
        </Grid>
        <Grid item xs={12}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Performance Metrics
            </Typography>
            <Line
              data={performanceData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                  y: {
                    beginAtZero: true,
                    max: 100,
                  },
                },
              }}
            />
          </Paper>
        </Grid>
      </Grid>
    </DashboardContainer>
  );
};

export default Dashboard; 