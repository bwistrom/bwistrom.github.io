from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import uvicorn
import asyncio
import json
from typing import Dict, Any
import logging
from pathlib import Path

from quantum_system.quantum_state import QuantumStateManager
from quantum_system.network import QuantumNetworkRouter
from quantum_system.monitoring import EnhancedMonitor
from quantum_system.security import QuantumSecurity
from quantum_system.optimization import SystemOptimizer
from quantum_system.websocket_manager import WebSocketManager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Quantum System API",
    description="API for Quantum Computing System with Web Interface",
    version="1.0.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize system components
quantum_state = QuantumStateManager()
network_router = QuantumNetworkRouter()
monitor = EnhancedMonitor()
security = QuantumSecurity()
optimizer = SystemOptimizer()
ws_manager = WebSocketManager()

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.on_event("startup")
async def startup_event():
    """Initialize system components on startup"""
    await quantum_state.initialize()
    await network_router.initialize()
    await monitor.initialize()
    await security.initialize()
    await optimizer.initialize()
    logger.info("System components initialized")

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup system components on shutdown"""
    await quantum_state.cleanup()
    await network_router.cleanup()
    await monitor.cleanup()
    await security.cleanup()
    await optimizer.cleanup()
    logger.info("System components cleaned up")

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for real-time communication"""
    await ws_manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            await ws_manager.handle_message(websocket, data)
    except WebSocketDisconnect:
        await ws_manager.disconnect(websocket)

@app.get("/api/status")
async def get_system_status():
    """Get current system status"""
    status = {
        "quantum_state": await quantum_state.get_status(),
        "network": await network_router.get_status(),
        "monitoring": await monitor.get_status(),
        "security": await security.get_status(),
        "optimization": await optimizer.get_status()
    }
    return status

@app.post("/api/optimize")
async def optimize_system():
    """Trigger system optimization"""
    result = await optimizer.optimize()
    return {"status": "success", "result": result}

@app.get("/api/performance")
async def get_performance_metrics():
    """Get system performance metrics"""
    metrics = await monitor.get_metrics()
    return metrics

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    ) 