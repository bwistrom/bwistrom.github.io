from typing import Dict, Any, List
import logging
from fastapi import WebSocket

class WebSocketManager:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.active_connections: List[WebSocket] = []
        
    async def connect(self, websocket: WebSocket):
        """Connect a new WebSocket client"""
        await websocket.accept()
        self.active_connections.append(websocket)
        self.logger.info(f"New WebSocket connection established. Total connections: {len(self.active_connections)}")
        
    async def disconnect(self, websocket: WebSocket):
        """Disconnect a WebSocket client"""
        self.active_connections.remove(websocket)
        self.logger.info(f"WebSocket connection closed. Total connections: {len(self.active_connections)}")
        
    async def broadcast(self, message: Dict[str, Any]):
        """Broadcast a message to all connected clients"""
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                self.logger.error(f"Error broadcasting message: {e}")
                
    async def handle_message(self, websocket: WebSocket, data: str):
        """Handle incoming WebSocket messages"""
        try:
            # Process the message and prepare a response
            response = {
                "status": "received",
                "message": data
            }
            await websocket.send_json(response)
        except Exception as e:
            self.logger.error(f"Error handling message: {e}") 