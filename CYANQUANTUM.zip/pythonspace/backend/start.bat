@echo off

REM Activate virtual environment if it exists
IF EXIST "venv\Scripts\activate.bat" (
    call venv\Scripts\activate.bat
) ELSE IF EXIST "..\venv\Scripts\activate.bat" (
    call ..\venv\Scripts\activate.bat
)

REM Install requirements
pip install -r requirements.txt

REM Start the server
uvicorn main:app --reload --host 0.0.0.0 --port 8000 