import subprocess
import sys
import ctypes

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def run_powershell_command(command):
    try:
        result = subprocess.run(['powershell', '-Command', command], 
                              capture_output=True, 
                              text=True, 
                              check=True)
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        print(f"Error executing command: {e}")
        print(f"Error output: {e.stderr}")
        return None

def configure_firewall():
    # Check if running as administrator
    if not is_admin():
        print("This script requires administrator privileges.")
        print("Please run the script as administrator.")
        sys.exit(1)

    print("Configuring Windows Firewall security settings...")

    # Enable Windows Firewall
    run_powershell_command('Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled True')

    # Set default inbound policy to block
    run_powershell_command('Set-NetFirewallProfile -Profile Domain,Public,Private -DefaultInboundAction Block')

    # Block all incoming connections
    run_powershell_command('Set-NetFirewallProfile -Profile Domain,Public,Private -AllowInboundRules False')

    # Enable logging for dropped packets
    run_powershell_command('Set-NetFirewallProfile -Profile Domain,Public,Private -LogFileName "%SystemRoot%\\System32\\LogFiles\\Firewall\\pfirewall.log" -LogMaxSizeKilobytes 16384 -LogAllowed True -LogBlocked True')

    print("\nFirewall configuration completed successfully!")
    print("\nImportant notes:")
    print("1. All incoming connections are now blocked by default")
    print("2. To allow specific applications or ports, you'll need to manually create rules")
    print("3. To create a new rule, you can use Windows Defender Firewall with Advanced Security")
    print("4. The firewall is now logging all blocked and allowed connections")
    print("\nTo manually allow specific connections:")
    print("1. Open Windows Defender Firewall with Advanced Security")
    print("2. Click on 'Inbound Rules'")
    print("3. Click 'New Rule' in the right panel")
    print("4. Follow the wizard to create a specific rule for your needs")

if __name__ == "__main__":
    configure_firewall() 