// Function to show a surprise message
function showMessage() {
    alert("You're not an idiot - you're a genius in training! 🎓");
}

// Add some fun animations when the page loads
document.addEventListener('DOMContentLoaded', function() {
    // Add a fun entrance animation to the container
    const container = document.querySelector('.container');
    container.style.opacity = '0';
    container.style.transform = 'translateY(20px)';
    
    setTimeout(() => {
        container.style.transition = 'all 1s ease';
        container.style.opacity = '1';
        container.style.transform = 'translateY(0)';
    }, 100);
}); 